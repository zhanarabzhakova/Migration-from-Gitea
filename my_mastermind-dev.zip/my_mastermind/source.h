#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef struct s_game_data{
    char* secret_code;
    int attempts;
} t_game_data;

t_game_data* init_struct();
int is_ok_code(char* code);
int is_number(char* str);
int my_atoi(char* str);
t_game_data* parse_parameters(t_game_data* game_data, int argc, char** argv);
char* input();
int check_code(char* original_code, char* user_code);
int count_well_placed(char* original_code, char* user_code);
int count_mis_placed(char* original_code, char* user_code);
