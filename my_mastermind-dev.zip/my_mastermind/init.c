#include "source.h"

t_game_data* init_struct(){
    t_game_data* t = (t_game_data*)malloc(sizeof(t_game_data));
    t->secret_code = (char*)malloc(5);
    t->secret_code[4] = '\0';
    strcpy(t->secret_code, "1234");
    t->attempts = 10;

    return t;
}