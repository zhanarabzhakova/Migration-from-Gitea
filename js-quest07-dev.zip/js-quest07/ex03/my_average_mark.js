var String = {};

function my_average_mark(String) {
    for (let i = 0; i < my_average_mark.length; i++){
        return (String.reduce((sum,hash) => sum + hash.integer, 0) / String.length).toFixed(1);
    
    }
}
