var String = [];

function my_count_on_it(String) {
    for (let i = 0; i < my_count_on_it.length; i++){
        return String.map(element => element.length);
    }
}