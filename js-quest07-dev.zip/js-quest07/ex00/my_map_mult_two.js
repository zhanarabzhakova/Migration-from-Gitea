var String = [];

function my_map_mult_two(String) {
    for (let i = 0; i < my_map_mult_two.length; i++){
        return String.map(x => x*2);
    }
}