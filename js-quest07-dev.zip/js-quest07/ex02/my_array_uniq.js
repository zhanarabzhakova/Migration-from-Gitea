var String = [];

function my_array_uniq(String) {
    for (let i=0; i < my_array_uniq.length; i++) {
        return String.filter((v,i,a) => a.indexOf(v) ===i);
    }
}