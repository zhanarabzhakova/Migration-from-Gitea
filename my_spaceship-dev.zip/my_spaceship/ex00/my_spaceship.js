function my_spaceship(String) {
    var direction = "up";
    var result = "";
    var x = 0;
    var y = 0;

    for (let i=0; i < String.length; i++){
        if (String[i] == 'A'){
            if (direction == "up"){
                y--;
            }
                else if (direction == "down"){
                    y++;
                }
                else if (direction == "left"){
                  x--;
                }
                else if (direction == "right"){ 
                    x++;
                }
                else return "n/a";
        }        
        else if (String[i] == 'R'){
            if (direction == "up"){
                direction = "right";
            }
                else if (direction == "down"){
                    direction = "left";
                }
                else if (direction == "left"){
                    direction = "up";
                }
                else if (direction == "right"){
                    direction = "down";
                }
        }
        else if (String[i] == 'L'){
             if (direction == "up"){
                direction = "left";
            }
                else if (direction == "down"){
                    direction = "right";
                }
                else if (direction == "left"){
                    direction = "down";
                }
                else if (direction == "right"){
                    direction = "up";
                }    
            }        
        ;
    }
    result = "{x: "+x+", y: "+y+", direction: '"+direction+"'}";
    return result
}
//console.log(my_spaceship("RAALALL"));