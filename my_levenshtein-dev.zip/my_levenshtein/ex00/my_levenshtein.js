function my_levenshtein(s1,s2) {
    var zero = 0;
    var result = 0;
    var negative = -1;
    if (s1.length == s2.length) {
        for (i = 0; i < s1.length; i++) {
            if (s1[i] === s2[i]) {
                zero += 0;
            } else {
                result +=1;
            }
        }
        result = result + zero
        return result
    }
    else {
        return -1
    }
}
//console.log(my_levenshtein("", ""))