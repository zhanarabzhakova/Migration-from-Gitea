int my_string_index(char* param_1, char param_2)
{
    int index = 0;
    while (index < strlen(param_1)){
        if (param_1[index]==param_2){
            return index;
        }
    index +=1;
    }
    return -1;
}