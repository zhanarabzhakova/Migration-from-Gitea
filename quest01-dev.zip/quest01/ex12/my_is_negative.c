#include <stdio.h>

int my_is_negative(int param_1){
    if (param_1 < 0) {
    return 0;
  }
  else {
    return 1;
  }
}