int my_isupper(char param_1){
    if (param_1 >= 'A' && param_1 <= 'Z'){
        return 1;
    }
    else {
        return 0;
    }
}
