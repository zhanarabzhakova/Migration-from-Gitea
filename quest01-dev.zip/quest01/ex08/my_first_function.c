#include <stdio.h>
// Following XXXXXX will be a function that will print using printf("my_first_function\n");
void 
my_first_function(){
    printf("my_first_function\n");
}

int main() {
  my_first_function();

  return 0;
}