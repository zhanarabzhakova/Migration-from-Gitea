int my_isdigit(int param_1){
    if (param_1 >= '0' && param_1 <= '9') {
        return 1;
    }
    else {
        return 0;
    }
}