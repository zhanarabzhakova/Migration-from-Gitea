#include <stdio.h>

int main() {
  char my_string[] = "Learning is growing";

  printf("%s\n", my_string);
  return 0;
}