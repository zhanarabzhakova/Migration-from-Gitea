#include <stdio.h>
int my_abs(int param_1){
    if (param_1 <0){
        return -1*param_1;
    }
    else{
        return param_1;
    }
}