char* my_spaceship(char* path)
{
    char* directions[4] = {"up", "right", "down", "left"};
    int x = 0;
    int y = 0;
    int current_direction = 0;
    for (int i=0; path[i] !='\0'; i++){
        if (path[i]=='R'){
            current_direction += 1;
        }
        else if(path[i]=='L'){
            current_direction -= 1;
            if (current_direction == -1){
                current_direction = 3;
            }
        }
        else {
            if (current_direction == 0){
                y--;
            }
            else if (current_direction == 1){
                x++;
            }
            else if (current_direction == 2){
                y++;
            }
            else {
                x--;
            }

        }

    }
char* res = malloc(50);
snprintf(res, 50, "{x: %d, y: %d, direction: '%s'}", x, y, directions[current_direction]);

return res;
}