function my_size(str) {
    return str.length;
}
//console.log(my_size("Zhanario"))
