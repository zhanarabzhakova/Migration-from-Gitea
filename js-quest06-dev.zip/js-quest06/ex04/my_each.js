var String = [];

function my_each(String) {
    
    for (let i=0; i < my_each.length; i++){
        String.forEach(function(item) {
        
        console.log(item)
                     });
                    }
}
       

//console.log(my_each("bah1","bah2","bah3"))