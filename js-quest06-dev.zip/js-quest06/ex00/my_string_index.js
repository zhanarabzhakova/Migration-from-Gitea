/*
1-What are the inputs?
2-What are the outputs?
3-What the function is doing?
*/

function my_string_index(haystack,needle) {
    var index=0

    while(index < haystack.length) {
        if (haystack[index] == needle) {
            return index;
        }
        index += 1;
    }
    return -1;
    };

//console.log(my_string_index("hello","l"))