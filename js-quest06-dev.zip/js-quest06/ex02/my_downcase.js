function my_downcase(str) {
    return str.toLowerCase();
 };
 //console.log(my_downcase("HELLO"))