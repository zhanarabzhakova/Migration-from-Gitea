#include <stdio.h>
#include <stdlib.h>

#define MAX_CHAR_COUNT 256

void count_letters_per_word(char* letters, char* str){
    for(int i = 0; str[i] !='\0';i++){
        letters[(int)str[i]] +=1;
    }
}

void count_letters(char* letters, char** str_arr, int len){
    for(int i = 1; i < len;i++){
        count_letters_per_word(letters, str_arr[i]);
    }
}

void output_result(char* letters){
    for(int i=0; i < MAX_CHAR_COUNT; i++){
        if((char)i == '"'){
            continue;
        }       

        if(letters[i] > 0){
            printf("%c:%d\n", i, letters[i]);
        }
    }
}
int main (int ac, char** av) {
    if (ac >  1){
        char letters[MAX_CHAR_COUNT] = {0};
        count_letters(letters, av, ac);  
        output_result(letters);
    }
    
    return 0; 
} 