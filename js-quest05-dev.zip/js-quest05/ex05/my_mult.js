function my_mult(nbr1,nbr2) {
    return nbr1*nbr2;
}
//console.log(my_mult(2,3))