function my_string_formatting(firstname,lastname,age) {
    console.log("Hello, my name is " + firstname +" "+ lastname + ", I'm "+ age +".")
}
//console.log(my_string_formatting(john,doe,37))