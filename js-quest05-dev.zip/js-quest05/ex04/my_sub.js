function my_sub(nbr1,nbr2) {
    return nbr1-nbr2;
}
//console.log(my_sub(6,4))