function my_abs(n) {
   return Math.abs(n);
    
}

//console.log(my_abs(-30))