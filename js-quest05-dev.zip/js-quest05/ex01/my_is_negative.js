function my_is_negative(n) {
    if (n < 0) {
        return 0;
    }
    else {
        return 1;
    }
}
//console.log(my_is_negative(-1))
//console.log(my_is_negative(1))
//console.log(my_is_negative(0))