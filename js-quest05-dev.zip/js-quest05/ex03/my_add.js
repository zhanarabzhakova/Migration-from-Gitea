function my_add(nbr1,nbr2) {
    return nbr1+nbr2;
}

//console.log(my_add(6,4))