int my_strcmp(char* param_1, char* param_2)
{
    int i = 0;
    int j = 0;
    for (i = 0; i < strlen(param_1); i++){
        if (param_1[i]>param_2[j]){
            return 1;
        }
        else if (param_1[i]==param_2[j]){
            return 0;
        }
        else {
            return -1;
        }
    }
}