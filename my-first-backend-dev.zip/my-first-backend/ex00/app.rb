require 'sinatra'

set :port, 8080

helpers do
    def protected!
      return if authorized?
      headers['WWW-Authenticate'] = 'Basic realm="Restricted Area"'
      halt 401, "Not authorized\n"
    end
  
    def authorized?
      @auth ||=  Rack::Auth::Basic::Request.new(request.env)
      @auth.provided? and @auth.basic? and @auth.credentials and @auth.credentials == ['admin', 'admin']
    end
  end

get '/' do
    ['Accidents Will Happen', 'Adeste Fideles', 'Ad-Lib Blues', 'Air For English Horn', 'Alice Blue Gown', 'All Alone', 'All By Myself', 'All I Do Is Dream of You', 'All I Need is the Girl', 'All My Tomorrows', 'All of Me', 'All of You', 'All or Nothing at All', 'All the Things You Are', 'All the Way', 'All the Way Home', 'All This and Heaven Too', 'All Through the Day', 'Almost Like Being in Love', 'Yours Is My Heart Alone'].sample()
end

get '/birth_date' do
    'December 12, 1915'
end

get '/birth_city' do
    'Hoboken, New Jersey'
end

get '/wives' do
    ['Nancy Barbato,', ' Ava Gardner,', ' Mia Farrow,', ' Barbara Marx']
end

get '/picture' do
    redirect 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Frank_Sinatra_%281957_studio_portrait_close-up%29.jpg/800px-Frank_Sinatra_%281957_studio_portrait_close-up%29.jpg'
end

get '/public' do
    "Everybody can see this page"
end 

get '/protected' do
    protected!
    "Welcome, authenticated client"
end 