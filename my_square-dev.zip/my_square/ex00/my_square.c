#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int my_square(int rows, int columns){
    int i,j;
        for (i=1; i<=rows; i++){
        for (j=1; j<=columns; j++){
            if(i==1&&j==1||i==rows&&j==1||i==1&&j==columns||i==rows&&j==columns){
                printf("o");
                continue;
            }
            if(i==1&&1<j<columns||i==rows&&1<j<columns){
                printf("-");
                continue;
        }
            if(1<i<rows&&j==1||1<i<rows&&j==columns){
                printf("|");
                continue;
            }
            else{
                printf(" ");
            }
    }
    printf("\n");
}
}
int main (int ac, char **av){
     if (ac != 3){
        return 0;
    }
    int rows = atoi(av[1]);
    int columns = atoi (av[2]);
   
    my_square(rows,columns);
}