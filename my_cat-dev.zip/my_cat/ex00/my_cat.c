#include <stdio.h>

int main(int argc, char **argv)
{
char str[500];
int i;
for (i = 1; i < argc; i++)
{
FILE *fp = fopen(argv[i], "r");
char c;
while (1)
{
c = fgetc(fp);
if ( feof(fp) )
{
break;
}
printf("%c", c);
}
fclose(fp);
}

}